package org.chat21.android.ui.contacts.listeners;

/**
 * Created by stefanodp91 on 04/01/18.
 */

public interface OnCreateGroupClickListener {
    void onCreateGroupClicked();
}
