package com.tuwaiq.halfway.model

data class Northeast(
    val lat: Double,
    val lng: Double
)