package com.tuwaiq.halfway.model

data class Viewport(
    val northeast: Northeast,
    val southwest: Southwest
)