package com.tuwaiq.halfway.model

data class PlusCode(
    val compound_code: String,
    val global_code: String
)