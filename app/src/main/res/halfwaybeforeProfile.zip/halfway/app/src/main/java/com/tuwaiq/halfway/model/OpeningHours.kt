package com.tuwaiq.halfway.model

data class OpeningHours(
    val open_now: Boolean
)