package com.tuwaiq.halfway.model

data class Location(
    val lat: Double,
    val lng: Double
)