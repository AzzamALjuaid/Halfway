package com.tuwaiq.halfway.model

data class Geometry(
    val location: Location,
    val viewport: Viewport
)