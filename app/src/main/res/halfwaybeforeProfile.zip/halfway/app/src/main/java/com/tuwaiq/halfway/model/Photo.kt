package com.tuwaiq.halfway.model

data class Photo(
    val height: Int,
    val photo_reference: String,
    val width: Int
)