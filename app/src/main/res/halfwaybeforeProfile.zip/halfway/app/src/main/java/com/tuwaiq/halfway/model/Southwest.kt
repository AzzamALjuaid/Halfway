package com.tuwaiq.halfway.model

data class Southwest(
    val lat: Double,
    val lng: Double
)